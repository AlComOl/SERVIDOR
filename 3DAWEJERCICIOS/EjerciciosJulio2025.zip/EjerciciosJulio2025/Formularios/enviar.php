<?php



$nombre=$_GET["nombre"];

$mail=$_GET["mail"];

$boton=$_GET["boton"];

print_r($_POST);

echo "Mi nombre es".$nombre."  el mail" .$mail." .";

?>

