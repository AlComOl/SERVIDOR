<?php
$usuarios=[ ['usuario'=>'estefania','password'=>'1111', 'nombre'=>'Estefania Maestre','rol'=>'ROLE_ALUMNO'],

 ['usuario'=>'julio','password'=>'2222', 'nombre'=>'Julio Noguera','rol'=>'ROLE_PROFE'],

 ['usuario'=>'jose','password'=>'4444', 'nombre'=>'José Vicente','rol'=>'ROLE_ALUMNO'],

 ['usuario'=>'ana','password'=>'333', 'nombre'=>'Ana Fuertes','rol'=>'ROLE_ALUMNO'],

 ['usuario'=>'admin','password'=>'999', 'nombre'=>'Administrador','rol'=>'ROLE_PROFE'],

];



?>