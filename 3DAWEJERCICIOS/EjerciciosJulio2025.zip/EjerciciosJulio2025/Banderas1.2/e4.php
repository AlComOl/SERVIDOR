<?php

$array= array("abcd","abc","de","hjjj","g","wer");
$longitud=count($array);
$mayor=0;
$menor=0;
for ($i=0; $i < $longitud; $i++) {
    for ($z=0; $z < strlen($array[$i]); $z++) { 

        $valor= strlen($array[$i]);

        if($valor>$mayor){
            $mayor=$valor;
            $menor=$mayor;
        }elseif($valor<$menor&&$valor<$menor){
            $menor=$valor;
        }

       
    }
     print_r($valor);
}

echo"<br>";


echo"La longitud mas corta es ".$menor." y a mas larga ".$mayor;


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>