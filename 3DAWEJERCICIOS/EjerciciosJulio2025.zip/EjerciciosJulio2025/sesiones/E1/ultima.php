<?php
session_start();





print_r($_SESSION['nombre']);

echo"<br><br>";

print_r($_SESSION['numero']);

echo"<br><br><br><br><br>";


 echo"<a href='./index.php'>Ir al index</a>";


?>